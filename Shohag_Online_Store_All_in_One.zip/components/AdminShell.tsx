"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { adminModules } from "@/lib/modules";
import { supabase } from "@/lib/supabase";

export default function AdminShell({children}:{children:React.ReactNode}) {
  const path = usePathname();
  const router = useRouter();
  const [checking,setChecking] = useState(true);
  const [authorized,setAuthorized] = useState(false);
  useEffect(()=>{
    let live=true;
    async function check(){
      if(!supabase){if(live){setChecking(false);setAuthorized(false)}return;}
      const {data:{session}}=await supabase.auth.getSession();
      if(!session){router.replace("/admin/login");return;}
      if(session.user.app_metadata?.role!=="admin"){
        await supabase.auth.signOut();router.replace("/admin/login");return;
      }
      if(live){setAuthorized(true);setChecking(false);}
    }
    check();
    return ()=>{live=false};
  },[router]);
  async function logout(){if(supabase)await supabase.auth.signOut();router.push("/admin/login");}
  if(path === "/admin/login") return <>{children}</>;
  if(checking) return <main className="wrap"><p>অ্যাডমিন অনুমতি যাচাই হচ্ছে...</p></main>;
  if(!authorized) return <main className="wrap"><div className="notice">Supabase সেটআপ বা অনুমোদিত অ্যাডমিন লগইন প্রয়োজন। <Link href="/admin/login">লগইন</Link></div></main>;
  return <div className="admin">
    <aside className="side">
      <h2>Shohag Admin</h2><p className="small">মডিউলার কন্ট্রোল প্যানেল</p>
      <nav className="nav">{adminModules.map(m=><Link key={m.href} href={m.href} style={{background:path===m.href?"#203b5e":undefined}}>{m.label}</Link>)}</nav>
      <button onClick={logout} style={{marginTop:16,background:"#b42318"}}>লগআউট</button>
    </aside>
    <main className="main">{children}</main>
  </div>;
}
