import CustomerUI from "@/components/CustomerUI";
export default function Page(){return <CustomerUI view="cart"/>;}
