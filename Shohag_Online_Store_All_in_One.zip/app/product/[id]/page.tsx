import CustomerUI from "@/components/CustomerUI";
export default async function ProductPage({params}:{params:Promise<{id:string}>}){const p=await params;return <CustomerUI view="product" productId={p.id}/>;}
