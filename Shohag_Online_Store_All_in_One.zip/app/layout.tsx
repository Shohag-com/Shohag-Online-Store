import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Shohag Online Store",
  description: "আপনার চাহিদার সব সমাধান, এখন এক ঠিকানায়",
};
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="bn"><body>{children}</body></html>;
}
