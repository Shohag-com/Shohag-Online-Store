"use client";
import {useState} from "react";
import {useRouter} from "next/navigation";
import {supabase} from "@/lib/supabase";
export default function Login(){
 const [email,setEmail]=useState("");const [token,setToken]=useState("");const [sent,setSent]=useState(false);const [message,setMessage]=useState("");const [busy,setBusy]=useState(false);const router=useRouter();
 async function send(e:React.FormEvent){e.preventDefault();setMessage("");if(!supabase){setMessage("আগে .env.local-এ Supabase URL ও publishable key সেট করুন।");return;}setBusy(true);const {error}=await supabase.auth.signInWithOtp({email:email.trim(),options:{shouldCreateUser:false}});setBusy(false);if(error)setMessage(error.message);else{setSent(true);setMessage("যদি ইমেইলটি অনুমোদিত হয়, OTP পাঠানো হয়েছে।");}}
 async function verify(e:React.FormEvent){e.preventDefault();if(!supabase)return;setBusy(true);const {error}=await supabase.auth.verifyOtp({email:email.trim(),token:token.trim(),type:"email"});setBusy(false);if(error){setMessage("OTP যাচাই হয়নি; কোড ও মেয়াদ পরীক্ষা করুন।");return;}const {data}=await supabase.auth.getSession();if(data.session?.user.app_metadata?.role!=="admin"){await supabase.auth.signOut();setMessage("এই অ্যাকাউন্টে admin অনুমতি নেই।");return;}router.push("/admin");}
 return <main className="wrap"><section className="card" style={{maxWidth:520,margin:"40px auto"}}><h1>অ্যাডমিন লগইন</h1><p className="muted">Supabase Email OTP। Auth email template ও redirect URL আগে কনফিগার করতে হবে।</p>
 {!sent?<form onSubmit={send}><label>অ্যাডমিন ইমেইল</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/><button disabled={busy}>{busy?"পাঠানো হচ্ছে...":"OTP পাঠান"}</button></form>:<form onSubmit={verify}><label>ইমেইলে পাওয়া OTP</label><input required inputMode="numeric" value={token} onChange={e=>setToken(e.target.value)}/><button disabled={busy}>{busy?"যাচাই হচ্ছে...":"OTP যাচাই"}</button></form>}
 {message&&<p role="status">{message}</p>}<p className="notice">পাসওয়ার্ড রিসেট, rate limiting এবং production-grade recovery flow পরবর্তী নিরাপত্তা ধাপে সম্পন্ন করতে হবে।</p></section></main>
}
