import Link from "next/link";
import {adminModules} from "@/lib/modules";
export default function Dashboard(){return <>
  <div className="module"><div><h1>ড্যাশবোর্ড</h1><p className="muted">Shohag Online Store — Admin Overview</p></div><span className="tag">Starter scaffold</span></div>
  <div className="notice">এখানে দেখানো সংখ্যা ডেমো; live database analytics এখনও সংযুক্ত নয়।</div>
  <div className="stats"><div className="stat"><p className="muted">মোট পণ্য</p><h2>—</h2></div><div className="stat"><p className="muted">নতুন অর্ডার</p><h2>—</h2></div><div className="stat"><p className="muted">মোট বিক্রি</p><h2>—</h2></div><div className="stat"><p className="muted">কম স্টক</p><h2>—</h2></div></div>
  <h2>অ্যাডমিন মডিউল</h2><div className="grid">{adminModules.filter(m=>m.href!=="/admin").map(m=><article className="card" key={m.href}><h3>{m.label}</h3><p className="muted">{m.desc}</p><Link href={m.href}>মডিউল খুলুন →</Link></article>)}</div>
</>}
