export default function ModulePage(){return <>
  <h1>রিপোর্ট ও অ্যানালিটিক্স</h1>
  <p className="muted">বিক্রি, অর্ডার, best sellers, low stock, date range।</p>
  <div className="notice"><strong>বর্তমান অবস্থা:</strong> ডেটা যুক্ত না হওয়া পর্যন্ত report demo placeholder।</div>
  <section className="card"><h2>এই মডিউলে পরিকল্পিত অপশন</h2>
  <ul>
    <li>তথ্য তালিকা দেখা ও অনুসন্ধান</li>
    <li>নতুন রেকর্ড যোগ করা ও বিদ্যমান রেকর্ড সম্পাদনা</li>
    <li>সক্রিয়/নিষ্ক্রিয় অবস্থা ও পরিবর্তনের সময় সংরক্ষণ</li>
    <li>ভূমিকা-ভিত্তিক অনুমতি এবং validation</li>
  </ul>
  <p className="muted">ডেটাবেস টেবিলের নাম: <code>orders</code> (যেখানে প্রযোজ্য)।</p>
  </section>
  <section className="card"><h2>বাস্তবায়নের পরবর্তী কাজ</h2>
  <ol><li>ফর্ম ও টেবিল UI তৈরি</li><li>server-side validation / Supabase queries</li><li>RLS policies ও অনুমতি পরীক্ষা</li><li>mobile view ও error states পরীক্ষা</li></ol></section>
</>}
