"use client";
import {useState} from "react";
import {supabase} from "@/lib/supabase";
export default function OrderPage(){
 const [f,setF]=useState({customer_name:"",phone:"",district:"ময়মনসিংহ",thana:"ধোবাউড়া",address:"",landmark:""});
 const [coords,setCoords]=useState<{latitude:number;longitude:number;accuracy:number}|null>(null);
 const [consent,setConsent]=useState(false);const [message,setMessage]=useState("");const [busy,setBusy]=useState(false);
 function change(e:React.ChangeEvent<HTMLInputElement|HTMLTextAreaElement|HTMLSelectElement>){setF({...f,[e.target.name]:e.target.value});}
 function gps(){setMessage("");if(!navigator.geolocation){setMessage("GPS নেই; হাতে ঠিকানা লিখুন।");return;}navigator.geolocation.getCurrentPosition(p=>{setCoords({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy});setConsent(true);},()=>setMessage("GPS পাওয়া যায়নি। অনুমতি দিন অথবা ঠিকানা লিখুন।"),{enableHighAccuracy:true,timeout:15000,maximumAge:0});}
 async function submit(e:React.FormEvent){e.preventDefault();setMessage("");if(!supabase){setMessage("Supabase configuration দরকার।");return;}if(f.thana!=="ধোবাউড়া"){setMessage("এখন শুধু ধোবাউড়া থানায় অর্ডার নেওয়া হচ্ছে।");return;}setBusy(true);
 const {error}=await supabase.from("orders").insert({customer_name:f.customer_name.trim(),phone:f.phone.trim(),district:f.district,thana:f.thana,address:f.address.trim(),landmark:f.landmark.trim()||null,latitude:consent&&coords?coords.latitude:null,longitude:consent&&coords?coords.longitude:null,location_consent:Boolean(consent&&coords),items:[],total_amount:0,status:"new"});
 setBusy(false);setMessage(error?"অর্ডার জমা হয়নি। RLS/setup পরীক্ষা করুন: "+error.message:"ডেমো অর্ডার জমা হয়েছে। পণ্য কার্ট ও মোট মূল্য এখনো সংযুক্ত নয়।");}
 return <main className="wrap"><a href="/">← হোমে ফিরুন</a><section className="card" style={{maxWidth:700,margin:"20px auto"}}><h1>অর্ডার ফর্ম</h1><div className="notice">প্রাথমিক ডেলিভারি এলাকা: ধোবাউড়া। GPS ঐচ্ছিক; হাতে লেখা ঠিকানা বাধ্যতামূলক।</div>
 <form onSubmit={submit}><label>ক্রেতার নাম</label><input required name="customer_name" value={f.customer_name} onChange={change}/><label>মোবাইল</label><input required name="phone" inputMode="tel" value={f.phone} onChange={change}/><label>জেলা</label><input required name="district" value={f.district} onChange={change}/><label>থানা</label><select name="thana" value={f.thana} onChange={change}><option>ধোবাউড়া</option></select><label>সম্পূর্ণ ঠিকানা</label><textarea required name="address" rows={3} value={f.address} onChange={change}/><label>ল্যান্ডমার্ক (ঐচ্ছিক)</label><input name="landmark" value={f.landmark} onChange={change}/>
 <section className="card"><button type="button" onClick={gps}>GPS লোকেশন নিন</button>{coords&&<p className="ok">লোকেশন নেওয়া হয়েছে; আনুমানিক নির্ভুলতা {Math.round(coords.accuracy)} মিটার।</p>}<label><input type="checkbox" style={{width:"auto"}} checked={consent} onChange={e=>setConsent(e.target.checked&&Boolean(coords))}/> GPS লোকেশন অর্ডারের সঙ্গে সংরক্ষণে সম্মতি দিচ্ছি</label>{coords&&<a target="_blank" rel="noreferrer" href={`https://www.google.com/maps?q=${coords.latitude},${coords.longitude}`}>ম্যাপে দেখুন</a>}</section>
 <button disabled={busy}>{busy?"জমা হচ্ছে...":"ডেমো অর্ডার জমা দিন"}</button></form>{message&&<p role="status">{message}</p>}</section></main>
}
