import CustomerUI from "@/components/CustomerUI";
export default function Home(){return <CustomerUI view="home"/>;}
