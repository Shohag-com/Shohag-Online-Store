import CustomerUI from "@/components/CustomerUI";
export default function Products(){return <CustomerUI view="products"/>;}
