# Shohag Online Store — All-in-One Master Guide (বাংলা)

এই ZIP-এ Customer Interface এবং Admin Panel একই Next.js প্রজেক্টে রাখা হয়েছে।
এটি একটি **starter/demo scaffold**; production-ready সম্পূর্ণ দোকান নয়।

## ১. একসঙ্গে থাকা পেজ

### কাস্টমার প্যানেল
- `/` — হোমপেজ
- `/products` — পণ্য তালিকা, নমুনা ক্যাটাগরি ফিল্টার ও সার্চ
- `/product/1` — পণ্যের নমুনা বিস্তারিত
- `/cart` — ব্রাউজারে ডেমো কার্ট
- `/checkout` — চেকআউটের নমুনা ফর্ম
- `/order` — নাম, ফোন, ঠিকানা ও ঐচ্ছিক GPS-সহ প্রাথমিক অর্ডার ফর্ম
- `/wishlist` — ব্রাউজারে ডেমো Wishlist
- `/account` — কাস্টমার অ্যাকাউন্টের ডেমো পেজ
- `/track-order` — অর্ডার ট্র্যাকিংয়ের ডেমো ফর্ম
- `/contact` — যোগাযোগ ফর্মের ডেমো
- `/faq` — সাধারণ প্রশ্ন

### অ্যাডমিন প্যানেল
- `/admin/login` — Supabase email OTP লগইনের প্রাথমিক পেজ
- `/admin` — ড্যাশবোর্ডের কাঠামো
- `/admin/products` — পণ্য মডিউল
- `/admin/categories` — ক্যাটাগরি মডিউল
- `/admin/orders` — অর্ডার মডিউল
- `/admin/customers` — কাস্টমার মডিউল
- `/admin/delivery` — ডেলিভারি মডিউল
- `/admin/coupons` — কুপন মডিউল
- `/admin/banners` — ব্যানার মডিউল
- `/admin/reviews` — রিভিউ মডিউল
- `/admin/reports` — রিপোর্ট মডিউল
- `/admin/settings` — সেটিংস মডিউল
- `/admin/security` — নিরাপত্তা মডিউল
- `/admin/features` — ফিচার রেজিস্ট্রি

## ২. প্রধান ফাইল কোথায়

- `app/` — সব ওয়েব পেজ ও রাউট
- `components/CustomerUI.tsx` — কাস্টমার প্যানেলের শেয়ার করা ইন্টারফেস
- `components/AdminShell.tsx` — অ্যাডমিন মেনু/লেআউট
- `lib/modules.ts` — অ্যাডমিন মডিউলের তালিকা
- `lib/supabase.ts` — Supabase ক্লায়েন্ট কনফিগারেশন
- `supabase/schema.sql` — ডেটাবেস টেবিল ও প্রাথমিক RLS নীতি
- `.env.example` — প্রয়োজনীয় environment variable-এর নামের নমুনা
- `README_BN.md` — সেটআপ নোট
- `IMPLEMENTATION_ROADMAP_BN.md` — পরবর্তী কাজের তালিকা

## ৩. Android মোবাইল থেকে চালানোর সাধারণ ধাপ

1. ZIP ডাউনলোড করে Extract করুন।
2. পুরো প্রজেক্ট GitHub repository-তে আপলোড করুন; ZIP-কে GitHub-এ শুধু ফাইল হিসেবে রেখে দিলে সাইট চলবে না—ভেতরের ফাইলগুলো repository root-এ থাকতে হবে।
3. Supabase project তৈরি করে SQL Editor-এ `supabase/schema.sql` পর্যালোচনা করে চালান।
4. Supabase Auth-এ email OTP, email template এবং allowed redirect URLs কনফিগার করুন।
5. `.env.example`-এর variable-গুলো Vercel Project Settings → Environment Variables-এ যোগ করুন:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
6. GitHub repository-টি Vercel-এ import করুন এবং deploy করুন।
7. deploy শেষে customer routes, admin login এবং database permissions পরীক্ষা করুন।

## ৪. নিরাপত্তা: খুব গুরুত্বপূর্ণ

- `service_role` key কখনো `NEXT_PUBLIC_` variable-এ বা browser code-এ রাখবেন না।
- Admin role trusted server/admin process দিয়ে `app_metadata.role=admin` হিসেবে সেট করতে হবে; customer/client নিজে role দিতে পারবে না।
- শুধু UI-তে login check থাকলেই ডেটাবেস নিরাপদ হয় না; Supabase RLS ও server-side validation বাধ্যতামূলক।
- GPS কেবল ব্যবহারকারীর স্পষ্ট অনুমতির পর সংগ্রহ করুন। অনুমতি না দিলে হাতে ঠিকানা দেওয়ার বিকল্প রাখুন।
- Public order submission-এ server-side validation, rate limiting/anti-spam এবং পণ্যের দাম/স্টক সার্ভারে যাচাই যোগ না করে live বিক্রি শুরু করবেন না।
- SQL schema বারবার চালালে কিছু policy আগে থেকেই থাকলে error হতে পারে; প্রয়োজন অনুযায়ী migration/policy cleanup করুন।

## ৫. এখনো সম্পূর্ণ নয়

এই প্যাকেজে বহু পেজের UI/route scaffold আছে, কিন্তু সব মেনুতে বাস্তব CRUD নেই। বিশেষ করে:
- Admin থেকে database-এ পণ্য/ক্যাটাগরি যোগ-সম্পাদনা-মুছে ফেলা
- প্রকৃত product image/video upload
- real cart + server-verified checkout/order total
- stock deduction এবং order status workflow
- COD ও manual bKash verification
- customer registration/login এবং order history
- real order tracking API
- coupon validation, banner/review moderation, sales reports
- password reset, rate limiting, audit logging ও production security tests

Cart ও Wishlist এখন browser localStorage-এ demo হিসেবে থাকে; admin/database-এর সঙ্গে synchronize হয় না। নমুনা পণ্য ও দাম বাস্তব নয়।

## ৬. আপডেট করার সহজ নিয়ম

- নতুন পেজ: `app/<route>/page.tsx`
- কাস্টমার UI-এর সাধারণ পরিবর্তন: `components/CustomerUI.tsx` এবং `app/globals.css`
- অ্যাডমিন মেনু/লেআউট: `components/AdminShell.tsx`
- ডেটাবেস পরিবর্তন: নতুন migration SQL লিখে পরীক্ষা করুন; production schema অন্ধভাবে overwrite করবেন না।
- প্রতিটি পরিবর্তনের পর `npm run typecheck` এবং `npm run build` চালিয়ে error ঠিক করুন।
