# বাস্তবায়ন রোডম্যাপ — ধাপে ধাপে

## Phase 1 — Foundation
- GitHub private repository
- Supabase project + schema
- Vercel deployment
- Environment variables
- Domain-free preview URL
- Basic mobile layout test

## Phase 2 — Authentication & Authorization
- Supabase email OTP configuration
- Admin-only allowlist/invite
- Trusted `app_metadata.role=admin`
- Password login/recovery flow
- OTP expiry and retry/rate limits
- Session revoke/logout
- RLS test with anon, normal user, admin

## Phase 3 — Catalog
- Categories CRUD + subcategories
- Product CRUD, SKU, images/video, price/sale price, stock, variants
- Storage buckets and upload limits
- Public catalog read-only
- Admin audit events

## Phase 4 — Cart & Order
- Cart in browser
- Server-side order creation endpoint
- Server loads prices from DB; ignores client-sent totals
- Validate stock and delivery area on server
- Order status transition rules
- COD first; manual bKash only after clear payment instructions
- Invoice and order confirmation

## Phase 5 — Dhobaurah delivery & GPS
- Delivery area table enabled only for Dhobaurah initially
- Customer selects area and provides full written address + landmark
- GPS request only after explicit click and browser permission
- GPS is optional; manual address always available
- Store coordinates only with consent
- Admin-only order detail shows map link
- Never collect background/live location
- Do not rely on GPS alone to decide thana; validate address/area server-side and confirm by phone

## Phase 6 — Business modules
- Customers and order history
- Coupons with server-side limits
- Banners
- Reviews moderation
- Sales/stock reports
- Store settings, SEO, tax and backup checklist
- Feature registry and versioned migrations

## Phase 7 — Production readiness
- Rate limiting/CAPTCHA/anti-spam
- Security headers and dependency updates
- Audit logs for admin changes
- Backup/restore test
- Privacy notice and consent text
- Error handling, empty/loading states
- Mobile and cross-browser test
- End-to-end test: guest order, out-of-area rejection, GPS denied, admin login, unauthorized user denied, order status update
- Do not advertise as secure/complete until these tests pass

## Suggested free-first hosting
- GitHub private repo for version control
- Supabase free tier for database/auth (limits apply)
- Vercel Hobby/free tier for a demo (usage and eligibility limits apply)
- Use provider's assigned subdomain initially; custom domain generally costs money
- Check current provider terms before relying on free service


## কাস্টমার UI-এর পরবর্তী কাজ
1. পণ্য/ক্যাটাগরি CRUD-কে Supabase-এ যুক্ত করা।
2. সার্ভার-সাইড cart/order API: পণ্যের দাম ও স্টক সার্ভারে যাচাই; ক্লায়েন্টের পাঠানো মোট মূল্য বিশ্বাস না করা।
3. কাস্টমার authentication, order history ও tracking-এ ফোন/অর্ডার যাচাই।
4. পেমেন্ট যাচাই, ডেলিভারি চার্জ এবং order status workflow।
5. GPS পাঠানোর আগে স্পষ্ট সম্মতি, RLS এবং অ্যাডমিন-শুধু লোকেশন access পরীক্ষা।
