-- Modular schema starter. Review policies and test before production.
create extension if not exists pgcrypto;

create table if not exists public.categories (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 slug text not null unique,
 parent_id uuid references public.categories(id) on delete set null,
 image_url text,
 sort_order integer not null default 0,
 is_active boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 slug text not null unique,
 description text not null default '',
 sku text unique,
 category_id uuid references public.categories(id) on delete set null,
 price numeric(12,2) not null check(price >= 0),
 sale_price numeric(12,2) check(sale_price is null or sale_price >= 0),
 stock integer not null default 0 check(stock >= 0),
 image_urls jsonb not null default '[]'::jsonb,
 video_urls jsonb not null default '[]'::jsonb,
 variants jsonb not null default '[]'::jsonb,
 is_active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.delivery_areas (
 id uuid primary key default gen_random_uuid(),
 division text,
 district text not null default 'ময়মনসিংহ',
 thana text not null unique,
 enabled boolean not null default false,
 delivery_fee numeric(10,2) not null default 0 check(delivery_fee >= 0),
 notes text,
 created_at timestamptz not null default now()
);
insert into public.delivery_areas(thana, district, enabled, delivery_fee)
values ('ধোবাউড়া','ময়মনসিংহ',true,0)
on conflict(thana) do nothing;

create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 order_number bigint generated always as identity unique,
 customer_name text not null check(length(trim(customer_name)) between 2 and 120),
 phone text not null check(length(trim(phone)) between 6 and 30),
 division text,
 district text not null default 'ময়মনসিংহ',
 thana text not null default 'ধোবাউড়া',
 address text not null check(length(trim(address)) between 4 and 500),
 landmark text,
 latitude double precision check(latitude is null or latitude between -90 and 90),
 longitude double precision check(longitude is null or longitude between -180 and 180),
 location_consent boolean not null default false,
 items jsonb not null default '[]'::jsonb,
 subtotal numeric(12,2) not null default 0 check(subtotal >= 0),
 delivery_fee numeric(10,2) not null default 0 check(delivery_fee >= 0),
 total_amount numeric(12,2) not null default 0 check(total_amount >= 0),
 payment_method text not null default 'cod' check(payment_method in ('cod','bkash_manual')),
 status text not null default 'new' check(status in ('new','confirmed','preparing','on_the_way','delivered','cancelled')),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now(),
 check((location_consent = false) or (latitude is not null and longitude is not null))
);

create table if not exists public.customers (
 id uuid primary key default gen_random_uuid(),
 full_name text not null,
 phone text not null unique,
 email text,
 created_at timestamptz not null default now()
);

create table if not exists public.coupons (
 id uuid primary key default gen_random_uuid(),
 code text not null unique,
 discount_type text not null check(discount_type in ('fixed','percent')),
 discount_value numeric(12,2) not null check(discount_value > 0),
 minimum_order numeric(12,2) not null default 0,
 usage_limit integer,
 starts_at timestamptz,
 ends_at timestamptz,
 is_active boolean not null default true
);

create table if not exists public.banners (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 image_url text not null,
 target_url text,
 sort_order integer not null default 0,
 is_active boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists public.reviews (
 id uuid primary key default gen_random_uuid(),
 product_id uuid references public.products(id) on delete set null,
 customer_name text not null,
 rating integer not null check(rating between 1 and 5),
 review_text text not null default '',
 status text not null default 'pending' check(status in ('pending','published','hidden')),
 created_at timestamptz not null default now()
);

create table if not exists public.store_settings (
 key text primary key,
 value jsonb not null default '{}'::jsonb,
 updated_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
 id uuid primary key default gen_random_uuid(),
 actor_user_id uuid,
 action text not null,
 entity_type text,
 entity_id text,
 details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

create table if not exists public.feature_registry (
 key text primary key,
 label text not null,
 version text not null default '0.1.0',
 status text not null default 'planned' check(status in ('planned','building','enabled','disabled')),
 notes text not null default '',
 updated_at timestamptz not null default now()
);

alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.delivery_areas enable row level security;
alter table public.orders enable row level security;
alter table public.customers enable row level security;
alter table public.coupons enable row level security;
alter table public.banners enable row level security;
alter table public.reviews enable row level security;
alter table public.store_settings enable row level security;
alter table public.admin_audit_logs enable row level security;
alter table public.feature_registry enable row level security;

-- Admin policies: trusted app_metadata role only. Do not let users set this themselves.
do $$
declare t text;
begin
 foreach t in array array['categories','products','delivery_areas','orders','customers','coupons','banners','reviews','store_settings','admin_audit_logs','feature_registry'] loop
  execute format('drop policy if exists "admin full access" on public.%I',t);
  execute format('create policy "admin full access" on public.%I for all to authenticated using ((auth.jwt() -> ''app_metadata'' ->> ''role'') = ''admin'') with check ((auth.jwt() -> ''app_metadata'' ->> ''role'') = ''admin'')',t);
 end loop;
end $$;

-- Public catalog read policies (active records only)
create policy "public read active categories" on public.categories
 for select to anon, authenticated using (is_active = true);
create policy "public read active products" on public.products
 for select to anon, authenticated using (is_active = true);
create policy "public read enabled delivery areas" on public.delivery_areas
 for select to anon, authenticated using (enabled = true);
create policy "public read active banners" on public.banners
 for select to anon, authenticated using (is_active = true);
create policy "public read published reviews" on public.reviews
 for select to anon, authenticated using (status = 'published');

-- Minimal public insert policy for the starter demo only.
-- Do not treat client-submitted prices, items, area text or GPS as trusted.
create policy "public submit Dhobaurah demo orders" on public.orders
 for insert to anon, authenticated with check (
  thana = 'ধোবাউড়া' and status = 'new'
  and subtotal >= 0 and delivery_fee >= 0 and total_amount >= 0
  and (location_consent = false or (latitude is not null and longitude is not null))
);

-- No public SELECT policy for orders/customers/coupons/settings/audit logs.
-- Production order creation should go through a server-side endpoint that validates
-- enabled delivery area, product IDs, stock, prices, coupon, totals, and rate limits.
