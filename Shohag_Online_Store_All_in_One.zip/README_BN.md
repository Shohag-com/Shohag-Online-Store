# Shohag Online Store — All-in-One ZIP

এই এক ZIP-এ Customer Interface ও Admin Panel একই Next.js প্রজেক্টে একত্রিত আছে।

**প্রথমে পড়ুন:** `MASTER_GUIDE_BN.md` — পেজ তালিকা, ফাইল কোথায়, Android থেকে deploy, নিরাপত্তা ও অসম্পূর্ণ কাজ।

অতিরিক্ত নোট: নিচে আগের সেটআপ নির্দেশনা রাখা হয়েছে।

---

# Shohag Online Store — Modular Admin Starter

এটি একটি modular Next.js + Supabase starter scaffold। উদ্দেশ্য হলো ফ্রি/ফ্রি-টিয়ার পরিবেশে ধাপে ধাপে একটি ই-কমার্স সিস্টেম তৈরি করা।

## এই সংস্করণে অন্তর্ভুক্ত
- Responsive admin shell ও sidebar/navigation
- Dashboard overview (ডেমো সংখ্যা)
- Products, Categories, Orders, Customers, Delivery Areas, Coupons, Banners, Reviews, Reports, Settings, Security, Feature Registry — আলাদা route/page
- ধোবাউড়া-প্রথম delivery-area rule-এর নকশা
- customer consent-ভিত্তিক GPS form component
- Supabase browser client configuration
- Modular SQL schema: products, categories, orders, customers, delivery areas, coupons, banners, reviews, settings, audit log
- RLS-এর restrictive policy template এবং deployment guide

## সতর্কতা — Production Ready নয়
এটি একটি professional starter scaffold, সম্পূর্ণ পরীক্ষিত production store নয়। অধিকাংশ admin CRUD action, secure server-side order endpoint, password reset flow, email OTP configuration, rate limiting, audit logging, backup/restore এবং end-to-end testing বাস্তবায়ন ও পরীক্ষা করতে হবে। UI route থাকা মানে ফিচারটি backend-সহ সম্পূর্ণ চালু—এমন নয়।

## মোবাইল থেকে ফ্রি-টিয়ার সেটআপ
1. ZIP ডাউনলোড করে Extract করুন।
2. GitHub-এ private repository তৈরি করে ফাইল আপলোড করুন।
3. Supabase-এ project তৈরি করুন।
4. SQL Editor-এ `supabase/schema.sql` চালান।
5. Project Settings → API থেকে Project URL এবং anon/publishable key নিন।
6. `.env.example` কপি করে `.env.local` তৈরি করে মান বসান।
7. Supabase Auth-এ Email OTP/password reset template ও redirect URL কনফিগার করুন।
8. কেবল নিজের অনুমোদিত অ্যাডমিন ইউজারে server-side trusted Admin API/ড্যাশবোর্ড পদ্ধতিতে `app_metadata.role = admin` দিন; কখনো client থেকে role সেট করতে দেবেন না।
9. GitHub repository Vercel-এ Import করে Environment Variables সেট করে Deploy করুন।
10. প্রথমে staging/demo data দিয়ে পরীক্ষা করুন; বাস্তব অর্ডার নেওয়ার আগে সব security checklist পাস করান।

## Environment variables
`NEXT_PUBLIC_SUPABASE_URL` এবং `NEXT_PUBLIC_SUPABASE_ANON_KEY` কেবল public/publishable values। `service_role` key কখনো `NEXT_PUBLIC_` variable-এ বা browser code-এ দেবেন না।

## Free tier
ফ্রি-টিয়ার প্ল্যানের limits, suspension, bandwidth, database storage, email sending এবং usage policy বদলাতে পারে। ফ্রি সাবডোমেইন সম্ভব; নিজস্ব domain সাধারণত আলাদা কেনা লাগে। Free tier-কে guaranteed unlimited hosting হিসেবে ধরবেন না।

## Security checklist
- সব টেবিলে RLS
- Public users কেবল অনুমোদিত order insert করতে পারে; অন্য order পড়তে পারে না
- Admin role শুধুমাত্র trusted server-side metadata-তে
- Server-side order validation; client-sent price/total বিশ্বাস নয়
- Rate limit, CAPTCHA/anti-spam, audit logs
- GPS শুধুমাত্র customer action + browser permission-এ; manual address fallback
- Customer location শুধু authorized admin-কে দেখানো
- Backup/restore test
- OTP/password reset expiry ও abuse limits
- Production-এর আগে dependency updates এবং security review


## কাস্টমার ইন্টারফেস আপডেট (ডেমো)

এই সংস্করণে মোবাইল-ফ্রেন্ডলি কাস্টমার UI যোগ করা হয়েছে: হোমপেজ, পণ্য তালিকা/ক্যাটাগরি ফিল্টার, পণ্যের বিস্তারিত, ব্রাউজারে ডেমো কার্ট, Wishlist, চেকআউট ফর্ম, অ্যাকাউন্ট ডেমো, অর্ডার ট্র্যাকিং ডেমো, যোগাযোগ ও FAQ। কার্ট ও Wishlist বর্তমান ব্রাউজারের localStorage-এ ডেমো হিসেবে থাকে। নমুনা পণ্য/দাম বাস্তব নয়; অ্যাডমিন/ডেটাবেসের সঙ্গে সিঙ্ক হয় না। চেকআউট, কাস্টমার লগইন, ট্র্যাকিং, পেমেন্ট, সার্ভার-সাইড অর্ডার ভ্যালিডেশন এবং পণ্যের আসল CRUD এখনো বাস্তবায়ন/পরীক্ষা করতে হবে।
